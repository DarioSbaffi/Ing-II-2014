<!DOCTYPE html>
<html lang="en">

	<head>
	
		<meta charset="utf-8">
		<title> <?php echo $title;?></title>
	
	</head>

	<body>

		<div id="container">
		
		<h1>Welcome to CodeIgniter!</h1>
		
		<h2>ADD</h2>

		<P>	 <?php echo $var1." + ".$var2. " = " .$addTotal;?></P>

		<h2>sub</h2>

		<P>	 <?php echo $var1." - ".$var2. " = " .$subTotal;?></P>

	</body>
</html>
