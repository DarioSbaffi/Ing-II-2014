<img src="<?=base_url()?>css/Imagenes/banner_01.jpg">
