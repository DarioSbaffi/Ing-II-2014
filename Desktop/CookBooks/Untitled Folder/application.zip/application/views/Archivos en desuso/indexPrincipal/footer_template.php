<details>
				
	<summary> Grupo De Desarrollo RSG</summary>
	<p>Sergio Ariel Reynoso</p>
	<p>Jorge Oscar Gianotti</p>
	<p>Dario Sbaffi</p>
					
</details>
