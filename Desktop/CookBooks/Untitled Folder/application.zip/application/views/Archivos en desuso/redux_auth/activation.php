Variables going to available to the activation email template.

<?php print $username; ?>
<?php print $password; ?>
<?php print $email; ?>
<?php print $activation; ?>