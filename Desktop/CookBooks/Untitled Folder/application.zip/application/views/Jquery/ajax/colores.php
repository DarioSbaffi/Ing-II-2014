<?php

if($_GET['color'] == "verde"){
	echo "El color verde es muy relajante";
}
if($_GET['color'] == "azul"){
	echo "El color azul es muy frio";
}
if($_GET['color'] == "rojo"){
	echo "El color rojo es muy pasional";
}

?>
