<?php

echo $_POST['anio']+1;
?>
