<?php

$porcinco = $_GET['numero']*5;
echo $porcinco;

?>
