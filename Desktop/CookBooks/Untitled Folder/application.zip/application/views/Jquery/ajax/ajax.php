<?php

echo date('c');

?>
