<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class Verificar_abm_model extends CI_Model {
 
    public function construct() {
        parent::__construct();
    }
    function verificar_categoria($crud){
		echo $crud;
	} 
    
    
}
